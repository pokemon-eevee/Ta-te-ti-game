import requests
from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.core.window import Window
from kivy.lang import Builder
from kivy.uix.image import Image
from kivy.uix.floatlayout import FloatLayout
from kivy.clock import Clock

# Dirección del servidor en Replit (cambia esto si es necesario)
SERVER_URL = 'https://9cfb3df2-910b-41ac-9228-06b37bf53057-00-28dvh4sjeyk4a.picard.replit.dev:8080/'

Builder.load_string("""
<MenuScreen>:
    FloatLayout:
        Image:
            source: 'TaTeTi_Icon.png'  # Logo agregado
            allow_stretch: True
            keep_ratio: False
            size_hint: 0.4, 0.4  # Tamaño del logo
            pos_hint: {'center_x': 0.5, 'center_y': 0.85}  # Centrado en la parte superior
        Image:
            source: 'interfaz_inicio.png'
            allow_stretch: True
            keep_ratio: False
            size_hint: 1, 1
        Button:
            text: 'Jugar Online'
            background_normal: ''
            background_color: (0, 0, 0, 0)
            color: (0, 0, 0, 0)
            on_press: root.start_game_online()
            size_hint: 0.8, 0.2
            pos_hint: {'center_x': 0.5, 'center_y': 0.7}
        Button:
            text: 'Jugar Offline'
            background_normal: ''
            background_color: (0, 0, 0, 0)
            color: (0, 0, 0, 0)
            on_press: root.start_game_offline()
            size_hint: 0.8, 0.2
            pos_hint: {'center_x': 0.5, 'center_y': 0.42}
        Button:
            text: 'Salir'
            background_normal: ''
            background_color: (0, 0, 0, 0)
            color: (0, 0, 0, 0)
            on_press: root.salir()
            size_hint: 0.8, 0.1
            pos_hint: {'center_x': 0.5, 'center_y': 0.129}
""")

class JuegoScreen(Screen):
    def __init__(self, modo_online=False, **kwargs):
        super().__init__(**kwargs)
        self.modo_online = modo_online
        self.tablero = [" " for _ in range(9)]
        self.jugador_actual = "X"

        self.layout = FloatLayout()

        # Imagen de fondo según el modo
        if self.modo_online:
            imagen_fondo = Image(source='interfaz_online_completa.png', allow_stretch=True, keep_ratio=False)
        else:
            imagen_fondo = Image(source='juego_offline_completo.png', allow_stretch=True, keep_ratio=False)

        imagen_fondo.size_hint = (1, 1)
        imagen_fondo.pos_hint = {'center_x': 0.5, 'center_y': 0.5}
        self.layout.add_widget(imagen_fondo)

        self.botones = []
        for fila in range(3):
            for columna in range(3):
                button = Button(
                    font_size=72,
                    on_press=self.on_button_press,
                    background_normal="",
                    background_color=(0, 0, 0, 0),
                    color=(1, 1, 1, 1),
                    size_hint=(0.3, 0.18),
                    pos_hint={'center_x': 0.2 + columna * 0.3, 'center_y': 0.65 - fila * 0.2}
                )
                button.index = fila * 3 + columna
                self.botones.append(button)
                self.layout.add_widget(button)

        back_button = Button(
            text="",
            size_hint=(None, None),
            width=100,
            height=100,
            background_normal="",
            background_color=(0, 0, 0, 0),
            on_press=self.volver_al_menu,
            pos_hint={'right': 1, 'top': 1}
        )
        self.layout.add_widget(back_button)

        self.add_widget(self.layout)

        if self.modo_online:
            self.obtener_tablero()

    def obtener_tablero(self):
        response = requests.get(f"{SERVER_URL}get_board")
        if response.status_code == 200:
            data = response.json()
            self.tablero = data['board']
            self.jugador_actual = data['turn']
            self.actualizar_botones()

    def on_button_press(self, instance):
        if self.tablero[instance.index] != " ":
            return

        self.tablero[instance.index] = self.jugador_actual
        instance.text = self.jugador_actual

        self.hacer_movimiento(instance.index, self.jugador_actual)

        self.jugador_actual = "O" if self.jugador_actual == "X" else "X"

        Clock.schedule_once(lambda dt: self.verificar_ganador(), 0.3)

    def hacer_movimiento(self, index, player):
        data = {'index': index, 'player': player}
        response = requests.post(f"{SERVER_URL}make_move", json=data)
        if response.status_code == 200:
            data = response.json()
            self.tablero = data['board']
            winner = data['winner']
            if winner:
                self.mostrar_popup(f"¡Jugador {winner} ha ganado!")
            elif " " not in self.tablero:
                self.mostrar_popup("¡Empate!")
            self.jugador_actual = data['next_turn']
            self.actualizar_botones()

    def actualizar_botones(self):
        for button in self.botones:
            button.text = self.tablero[button.index]

    def verificar_ganador(self):
        combinaciones_ganadoras = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6]
        ]
        for combinacion in combinaciones_ganadoras:
            if self.tablero[combinacion[0]] == self.tablero[combinacion[1]] == self.tablero[combinacion[2]] != " ":
                self.mostrar_popup(f"¡Jugador {self.tablero[combinacion[0]]} ha ganado!")
                return

        if " " not in self.tablero:
            self.mostrar_popup("¡Empate!")

    def mostrar_popup(self, mensaje):
        layout = BoxLayout(orientation='vertical', padding=10)
        label = Label(text=mensaje, font_size=24)
        boton = Button(text="Cerrar", on_press=self.reiniciar_juego)
        layout.add_widget(label)
        layout.add_widget(boton)
        self.popup = Popup(title="Fin del Juego", content=layout, size_hint=(None, None), size=(400, 200))
        self.popup.open()

    def volver_al_menu(self, instance):
        self.manager.current = 'menu'

class MenuScreen(Screen):
    def start_game_offline(self):
        self.manager.add_widget(JuegoScreen(name='juego', modo_online=False))
        self.manager.current = 'juego'

    def start_game_online(self):
        self.manager.add_widget(JuegoScreen(name='juego', modo_online=True))
        self.manager.current = 'juego'

    def salir(self):
        App.get_running_app().stop()

class TaTeTiApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(MenuScreen(name='menu'))
        return sm

if __name__ == "__main__":
    TaTeTiApp().run()